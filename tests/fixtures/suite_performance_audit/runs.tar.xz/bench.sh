#!/bin/bash
# Serial default suite, alternating pre (1f6abad) and post (d0948fb), 3 rounds.
set -u
OUT=/tmp/af338/out
cd /tmp
for d in pre post; do
  rm -rf /tmp/af338/t && mkdir /tmp/af338/t
  (cd /tmp/af338/$d && TMPDIR=/tmp/af338/t .venv/bin/python -m pytest -p no:cacheprovider --collect-only -q > $OUT/$d-collect.log 2>&1)
  rm -rf /tmp/af338/t
done
for r in 1 2 3; do
  for d in pre post; do
    rm -rf /tmp/af338/t && mkdir /tmp/af338/t
    echo "$d $r start $(date -u +%FT%TZ) load $(cut -d' ' -f1-3 /proc/loadavg)" >> $OUT/events.log
    (cd /tmp/af338/$d && TMPDIR=/tmp/af338/t timeout 2700 /usr/bin/time -f '%e %U %S %M' -o $OUT/$d-$r.time \
       .venv/bin/python -m pytest -p no:cacheprovider --junitxml=$OUT/$d-$r.xml > $OUT/$d-$r.log 2>&1)
    rc=$?
    echo "$d $r end $(date -u +%FT%TZ) rc $rc load $(cut -d' ' -f1-3 /proc/loadavg) inodes $(df --output=iused /tmp/af338/t | tail -1)" >> $OUT/events.log
    rm -rf /tmp/af338/t
  done
done
echo done >> $OUT/events.log
